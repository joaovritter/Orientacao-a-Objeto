package exemplo1;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cachorro c = new Cachorro();
		c.especie = "Dog ";
		c.idade = 17;
		c.emiteSom();
		c.mostrarDados();
		c.cuidarPatio();
		c.exibirDados();
		
	}
}
