package exemplo1;

public class Cachorro extends Animal {
	private String raca;
	@Override
	public void emiteSom() {
		System.out.println("AAUAUAU");		
	}
	public void cuidarPatio() {
		System.out.println("o cachorro ta tentando cuida do patiao");
	}
	
	public void exibirDados () {
		System.out.println("Raca: "+raca+ "  Idade: "+idade+ "  Especie: "+ especie);
	}

	
	
}
