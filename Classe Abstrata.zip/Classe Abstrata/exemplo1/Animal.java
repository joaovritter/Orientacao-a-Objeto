package exemplo1;

public abstract class Animal {
	protected String especie;
	protected int   idade;

	
	public abstract void emiteSom();
	
	public void mostrarDados() {
		System.out.println("Especie: "+especie+"  Idade: " + idade);
	}
	
	
	
}
