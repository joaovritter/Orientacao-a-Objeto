package exercicio6;

public class Livro implements Produto {
	String nome;
	String descricao;
	double preco;
	
	public Livro(String nome, String descricao, double preco) {
	
		this.nome = nome;
		this.descricao = descricao;
		this.preco = preco;
	}

	@Override
	public void getNome() {
		System.out.println("Nome: " + this.nome);
	}

	@Override
	public void getPreco() {
		// TODO Auto-generated method stub
		System.out.println("Preco: " +this.preco);
	}

	@Override
	public void getDescricao() {
		// TODO Auto-generated method stub
		System.out.println("Descricao: "+this.descricao);
	}

}
