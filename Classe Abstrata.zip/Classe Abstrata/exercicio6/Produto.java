package exercicio6;

public interface Produto {
	public void getNome();
	public void getPreco();
	public void getDescricao();
}