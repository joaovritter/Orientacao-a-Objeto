package exercicio6;

public class Principal {
	public static void main (String[] args) {
	Livro l = new Livro ("Joao dedo de arroz",  "Lviro pra belho", 1000);
	Cd c = new Cd ("Banda djavu", "e dj juninho portugal", 1313131);
	l.getNome();
	l.getPreco();
	l.getDescricao();
	c.getNome();
	c.getPreco();
	c.getDescricao();
	}
}
