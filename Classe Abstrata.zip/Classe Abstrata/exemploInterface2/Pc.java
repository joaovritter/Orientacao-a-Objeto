package exemploInterface2;

public interface Pc {
	
	public void verificaEmail();
	
}
