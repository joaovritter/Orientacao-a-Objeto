package exemploInterface2;

public class Smartphone implements Pc, Celular {
	String tel, email;
	
	
	public Smartphone(String tel, String email) {
		super();
		this.tel = tel;
		this.email = email;
	}

	@Override
	public void realizarChamada() {
		System.out.println("chamando");
	}

	@Override
	public void verificaEmail() {
		System.out.println("adadas");

	}

}
