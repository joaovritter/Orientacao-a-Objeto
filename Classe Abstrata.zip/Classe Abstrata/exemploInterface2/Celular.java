package exemploInterface2;

public interface Celular {
	public void realizarChamada();
}
