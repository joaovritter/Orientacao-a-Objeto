package exercicio1;

public abstract class Conta {
	public double saldo, limite;
	
	public abstract double depositar ();
	public abstract double sacar ();
}
