package exercicio1;

public class ContaInvestimento extends Conta{

	@Override
	public double depositar() {
		System.out.println("Depoistado 10000 reais na conta magrao");
		return saldo = saldo + 10000;
	}

	@Override
	public double sacar() {
		// TODO Auto-generated method stub
		System.out.println("Sacado 200tao da conta");
		return saldo = saldo - 200;
	}
	
	
}
