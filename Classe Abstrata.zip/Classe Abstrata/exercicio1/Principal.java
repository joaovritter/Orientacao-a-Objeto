package exercicio1;

public class Principal {

	public static void main(String[] args) {
		ContaInvestimento ci = new ContaInvestimento ();
		ContaCorrente cc = new ContaCorrente();
		ci.depositar();
		ci.sacar();
		
		cc.depositar();
		cc.sacar();
		
	}

}
