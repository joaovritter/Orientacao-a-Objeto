package exemplo2;

public class Retangulo extends Formas {
	public double largura, altura;

	public Retangulo(double largura, double altura) {
		super();
		this.largura = largura;
		this.altura = altura;
	}
	
	public double area() {
		return largura*altura;
	}
	
	public double perimetro() {
		return 2*(largura+altura);
	}
}
