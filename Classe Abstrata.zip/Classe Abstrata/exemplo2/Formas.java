package exemplo2;

public abstract class Formas {
	

	
	
	
	
}
