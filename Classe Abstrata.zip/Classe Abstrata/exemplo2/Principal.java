package exemplo2;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Retangulo r = new Retangulo(3,5);
		r.area();
		r.perimetro();
		
		Circulo c = new Circulo (5);
		c.area();
		c.perimetro();
		
	}
}
