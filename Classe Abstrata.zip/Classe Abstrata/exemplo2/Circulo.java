package exemplo2;

public class Circulo {
	public double raio;
	
	public Circulo(double raio) {
		super();
		this.raio = raio;
	}
	public double area() {
	return 3.14 *(raio*raio);
	}
	public double perimetro() {
		return 2* (3.14*raio) ;
		}
	
}
