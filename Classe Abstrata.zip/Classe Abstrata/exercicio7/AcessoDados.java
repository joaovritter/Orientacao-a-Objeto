package exercicio7;

public interface AcessoDados {
	public void conectar(); 
	public void desconectar();
	public void inserir();
	public void atualizar();
	public void excluir();
}
