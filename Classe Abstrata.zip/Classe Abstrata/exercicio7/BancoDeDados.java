package exercicio7;

public class BancoDeDados implements AcessoDados {

	@Override
	public void conectar() {
		System.out.println("Conectado");
	}

	@Override
	public void desconectar() {
		// TODO Auto-generated method stub
		System.out.println("desconectado");
	}

	@Override
	public void inserir() {
		// TODO Auto-generated method stub
		System.out.println("inserido");
	}

	@Override
	public void atualizar() {
		// TODO Auto-generated method stub
		System.out.println("atualizando");
	}

	@Override
	public void excluir() {
		// TODO Auto-generated method stub
		System.out.println("excluido");
	}

}
