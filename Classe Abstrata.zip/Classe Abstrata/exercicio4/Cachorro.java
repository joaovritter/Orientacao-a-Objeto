package exercicio4;

public class Cachorro extends Animal {
	private String raca;
	
	public String getRaca() {
		return raca;
	}
	public void setRaca(String raca) {
		this.raca = raca;
	}
	@Override
	public void emiteSom() {
		System.out.println("AAUAUAU");		
	}
	public void cuidarPatio() {
		System.out.println("o cachorro ta tentando cuida do patiao");
	}
	
	public void exibirDados () {
		System.out.println("Raca: "+getRaca()+ "  Idade: "+getIdade()+ "  Especie: "+ getEspecie());
	}

	
	
}
