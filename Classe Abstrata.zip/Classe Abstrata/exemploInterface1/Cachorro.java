package exemploInterface1;

public class Cachorro implements Animal {
	public String nome;
	public int idade;
	public void emitirSom() {
		System.out.println("ADADADADADa");
	}
	public void exibirDados() {
	}
	
	public void cuidarPatio() {
		System.out.println("Cuidando do patio");
	}
	
}
