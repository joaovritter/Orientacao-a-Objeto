package exemploInterface1;

public class Gato implements Animal {
	public String nome;
	public int idade;
	@Override
	public void emitirSom() {
		// TODO Auto-generated method stub
		System.out.println("MIAAAAAu");
	}

	@Override
	public void exibirDados() {
		// TODO Auto-generated method stub

	}

}
