package exemploInterface1;

public interface Animal {
	
	public void emitirSom();
	public void exibirDados();
}
