package exemploInterface1;

public class Principal {

	public static void main(String[] args) {
		Cachorro c = new Cachorro ();
		c.emitirSom();
		
		Gato g = new Gato ();
		g.emitirSom();
		
		c.cuidarPatio();
		c.idade = 15;
		c.nome = "CADELAO";
		
		g.nome = "Garfiudi";
		g.idade = 67;
		System.out.println("Nome: " +c.nome + "  Idade: " +c.idade);
		System.out.println("Nome: " +g.nome + "  Idade: " +g.idade);
	}

}
