package exercicio5;

public class Resposta {
	// pode por os metodos emitir som e mostrar dados na interface animal.
	// na conta nao pode pois tem atributos.
}
